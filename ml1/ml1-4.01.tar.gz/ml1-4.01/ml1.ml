(* CS421 - Fall 2016
 * ML1
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You will want to change how a number of these start.
 *)

open Common


let title = "" (* You want to change this *)

let greetings = "" (* You want to change this *)

let address = "" (* You want to change this *)

let frozen = ""  (* You want to change this *)

let daffy = ""  (* You want to change this *)

let a = 0.0 (* You want to change this *)

let pi = 0.0 (* You want to change this *)

let e = 0.0 (* You want to change this *)

let quarter = 0.0 (* You want to change this *)

let x = 0.0 (* You want to change this *)

let myFirstFun n = raise (Failure "Function not implemented yet.")

let firstFun n = raise (Failure "Function not implemented yet.")

let square n = raise (Failure "Function not implemented yet.")

let times_13 n = raise (Failure "Function not implemented yet.")

let cube n = raise (Failure "Function not implemented yet.")

let add_a n = raise (Failure "Function not implemented yet.")

let circumference r = raise (Failure "Function not implemented yet.")

let divide_e_by x = raise (Failure "Function not implemented yet.")

let plus_quarter_times_3 y = raise (Failure "Function not implemented yet.")

let square_plus_x y = raise (Failure "Function not implemented yet.")

let salutations name =  raise (Failure "Function not implemented yet.")

let hail name = raise (Failure "Function not implemented yet.")

let welcome name = raise (Failure "Function not implemented yet.")

let greet name = raise (Failure "Function not implemented yet.")

let salute name =  raise (Failure "Function not implemented yet.")

let rectangle_area l w =  raise (Failure "Function not implemented yet.")

let diff_square_9 m n = raise (Failure "Function not implemented yet.")

let make_bigger x y = raise (Failure "Function not implemented yet.")

let has_smallest_square m n = raise (Failure "Function not implemented yet.")

let sign_times n m = raise (Failure "Function not implemented yet.")

